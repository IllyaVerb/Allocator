#pragma once
#define PAGE_SIZE 4096
#define ARENA_PAGES 16